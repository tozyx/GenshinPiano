# CrispEmbed

[![Build](https://github.com/CrispStrobe/CrispEmbed/actions/workflows/build.yml/badge.svg)](https://github.com/CrispStrobe/CrispEmbed/actions/workflows/build.yml)

**A single C++/ggml binary for retrieval and document understanding — no Python
runtime, no ONNX.** Text/image/face embeddings, sparse & multi-vector retrieval,
rerankers, a full OCR stack (general, scene-text, math, music), layout analysis,
NER/KIE, and document preprocessing — all auto-detected from GGUF metadata and
GPU-accelerated (CUDA / Vulkan / Metal), with Python, Rust, Dart, HTTP, and
**WebAssembly** front-ends.

Where llama.cpp focuses on text *generation*, CrispEmbed covers the *retrieval,
understanding, and document-processing* half of the ggml world. **9.5× faster
than FastEmbed (ONNX)** on MiniLM-L6; runs on Linux, macOS, Windows, iOS,
Android, and in the browser.

> **Live demos:** [WASM OCR (client-side)](https://crispstrobe.github.io/CrispEmbed/)
> · [HuggingFace Space](https://huggingface.co/spaces/cstr/CrispEmbed) (embeddings + math OCR)

> **Experimental, default-off engines.** The newer document VLMs (Unlimited-OCR-2,
> MiniCPM-OCR, TeleOCR, MinerU2.5-Pro, OXR-1.0, OvisOCR2), MoEdernColBERT, Josev-2B
> SystemOne and the inpainting engines each need an environment gate (and some a
> license acknowledgement). They are listed in the tables below; every gate is in
> [docs/environment-variables.md](docs/environment-variables.md).

---

## Capabilities at a glance

| Domain | What it does | Highlights |
|---|---|---|
| **Text embeddings** | Dense vectors from 10 encoder/decoder architectures | BERT, XLM-R, MPNet, NomicBERT (+MoE), ModernBERT, GTE-v1.5, DeBERTa-v2, Qwen3, Gemma3. Matryoshka truncation, prompt prefixes. cos ≥ 0.965 vs HF |
| **Retrieval** | Sparse + multi-vector + reranking | SPLADE / BGE-M3 sparse term weights, ColBERT per-token + MaxSim, cross-encoder & bi-encoder rerankers |
| **Typed decisions** | State + question schemas → choices, integer scores or booleans | [EmbeddingGemma 2 fine-tune](docs/embeddinggemma2-typed-decision.md), complete encoder/head and fitted calibration; opt-in CPU. Python-reference parity checked; independent task accuracy unmeasured |
| **OCR** | 15+ engines, image → text/LaTeX/notation | General (DBNet+TrOCR), scene-text (PARSeq), 7 math engines, 4 music (OMR) engines, 6 document VLMs, 12-language Tesseract-LSTM |
| **Document AI** | Understand page structure | RT-DETRv2 layout (17 classes), Surya text detection, LiLT layout-aware KIE, hOCR/ALTO/searchable-PDF output; [native Marker-style PDF/image conversion](docs/marker.md) to Markdown/HTML/JSON/chunks (experimental, opt-in, TeleOCR backend) |
| **NER / KIE / LID** | Extract structured info | Zero-shot (GLiNER) + fixed-label (BERT/XLM-R) NER, receipt/form KIE, CLD3/GlotLID language ID |
| **Vision & face** | Cross-modal + biometrics | CLIP/SigLIP text-image search, YuNet/SCRFD detect, ArcFace/SFace/AuraFace recognize |
| **Preprocessing** | Clean & upscale before OCR | Classical deskew/binarize/dewarp, NAFNet denoise, TPS dewarp, 8 super-resolution engines, PDF-DPI auto-tuning |
| **Inpainting** (experimental) | Remove masked regions, e.g. burned-in subtitles | MI-GAN256/512, Moebius and PixelHacker (+ SDXL VAE), DBNet text masks, `--inpaint-stream` video mode; default-off |

Everything ships in one library with a unified C ABI. Over **100 models** (200+
GGUF variants) are in the auto-download registry — run `crispembed --list-models`
for the authoritative, always-current list with per-model license tags.

---

## Quick start

```bash
# Clone (with the ggml submodule) and build
git clone --recursive https://github.com/CrispStrobe/CrispEmbed
cd CrispEmbed
cmake -S . -B build && cmake --build build -j        # macOS: ./build-macos.sh (Metal)

# Text embedding (auto-downloads the model by name, or pass a local .gguf)
./build/crispembed -m all-MiniLM-L6-v2 "Hello world"
./build/crispembed -m model.gguf -d 128 "Hello world"          # Matryoshka: 128 dims
./build/crispembed -m model.gguf --prefix "query: " "Hello"    # prompt prefix

# Retrieval modalities (BGE-M3)
./build/crispembed -m bge-m3 --sparse  "Hello world"
./build/crispembed -m bge-m3 --colbert "Hello world"
./build/crispembed -m bge-reranker-v2-m3 --rerank "capital of france" \
    "Paris is the capital of France." "Bicycles have two wheels."

# OCR / document AI (engine auto-detected from GGUF metadata)
./build/crispembed -m ppformulanet-l  --ocr formula.png       # math → LaTeX
./build/crispembed -m flova           --ocr score.png         # music → LilyPond
./build/crispembed -m transcoda       --ocr page.png          # full-page score → **kern
./build/crispembed -m qwen3vl-2b      --ocr document.png      # VLM document OCR
./build/crispembed -m qwen3vl-2b      --ocr ui.png --ocr-prompt "Extract only the menu text."

# Experimental document VLMs (gated; the alias auto-downloads when --ocr-rec is omitted)
CRISPEMBED_UNLIMITED_OCR2=1 ./build/crispembed --ocr-pipeline page.png --ocr-engine unlimited-ocr2
CRISPEMBED_MINICPM_OCR=1 CRISPEMBED_QWEN35_OCR=1 \
  ./build/crispembed --ocr-pipeline page.png --ocr-engine minicpm-ocr
CRISPEMBED_MINERU25_PRO=1 \
  ./build/crispembed --ocr-pipeline page.png --ocr-engine mineru25-pro --ocr-rec mineru25-pro-f16

# Cross-modal & face
./build/crispembed -m clip-vit-base-patch16 --image photo.jpg
./build/crispembed -m yunet --detect photo.jpg --json

# HTTP server (text + vision + face + CLIP + OCR + NER in one process)
./build/crispembed-server -m all-MiniLM-L6-v2 --ocr ppformulanet-l-q8_0.gguf --port 8080
curl -X POST http://localhost:8080/embed -d '{"texts": ["Hello world"]}'
```

For modular document parsing, start the orchestrator with independent layout,
table, and formula modules:

```bash
./build/crispembed-server --ocr-pipeline \
  --ocr-det dbnet-ic15-q4_k.gguf --ocr-rec trocr-small-printed-q8_0.gguf \
  --layout layout-heron-f32.gguf \
  --table tesseract-eng-f16.gguf --tables \
  --formula ppformulanet-l-q4_k.gguf --formulas
curl http://localhost:8080/capabilities
```

The server also provides `/health/live` and `/health/ready`. `/health` doubles as
a capability probe (`reranker`, `sparse`, `colbert`, `ocr_pipeline`, `layout`, …),
but those keys are **present-when-active**: an inactive capability is omitted
rather than reported as `false`, so test for the key's presence, not its value.
Text recognition can be swapped independently for TrOCR, Tesseract-LSTM,
PP-OCRv6, EasyOCR, PARSeq, or a VLM.

With a cross-encoder loaded the server exposes reranking on two routes. `POST
/rerank` is the native shape (raw classifier logits). `POST /v1/rerank` speaks
the de-facto Cohere / Jina schema, so `crispembed-server` drops into LiteLLM,
LlamaIndex, LangChain or llama-swap without an adapter:

```bash
crispembed-server -m bge-reranker-v2-m3-q4_k.gguf
curl http://localhost:8080/v1/rerank -H 'Content-Type: application/json' -d '{
  "model": "bge-reranker-v2-m3",
  "query": "What is the capital of France?",
  "documents": ["Paris is the capital of France.", "Berlin is in Germany."],
  "top_n": 2, "return_documents": true }'
```

`documents` accepts both `["text", …]` and `[{"text": "…"}, …]`.
`relevance_score` is `sigmoid(logit)`, i.e. the 0..1 range those clients
threshold against — the transform is monotonic, so the ranking matches
`/rerank`'s exactly; `CRISPEMBED_SERVER_RERANK_RAW_SCORES=1` emits the raw logit
instead. `document` is echoed only when `"return_documents": true`, matching
Cohere's default.

**Matryoshka truncation over HTTP.** Models trained for it (jina-v5, EmbeddingGemma,
Qwen3-Embedding, …) keep most of their retrieval quality at a fraction of their
native width. The server truncates *and* L2-renormalizes, so clients receive
unit vectors of the requested length and never download the discarded tail:

```bash
crispembed-server -m jina-v5-nano --dim 256          # default for every request
curl http://localhost:8080/v1/embeddings -d '{"input": ["hi"], "dimensions": 128}'
```

`"dimensions"` (the OpenAI / Ollama field name) is accepted on `/embed`,
`/v1/embeddings`, `/api/embed` and `/api/embeddings` and overrides `--dim` for
that request only; a value outside 1..native returns 400. `/health` keeps `dim`
as the native size and adds `output_dim` when `--dim` is active.

**Offline operation.** `--offline` (CLI and server), `CRISPEMBED_OFFLINE=1`,
`HF_HUB_OFFLINE=1`, or `crispembed.set_offline(True)` in Python forbid every
download: model names resolve only to already-cached files (see `--cache-dir`)
and explicit paths, and a missing model fails with the path it was expected at
instead of reaching out to the network. Stage the cache ahead of time on a
connected machine, then deploy.

**Custom VLM OCR prompts.** `--ocr-prompt TEXT` (CLI and server; per-request
`"prompt"` on `POST /ocr/model`; `CrispOcrModel.set_prompt()` in Python) replaces
the instruction sent to prompt-following VLMs: Qwen2/2.5/3-VL (incl.
PaddleOCR-VL, olmOCR), InternVL2, LFM2-VL and Granite-Vision. Formula/line
recognizers and fixed-task document VLMs (GOT, GLM-OCR, LightOnOCR,
DeepSeek-OCR2, …) run the task prompt they were trained on and warn that the
option is ignored. Unknown command-line options now warn instead of being
silently swallowed as input text.

**Token usage, load control and OpenAI-shaped OCR.**

- `/v1/embeddings` `usage.prompt_tokens` (and `/api/embed`'s
  `prompt_eval_count`) report the tokenizer ids the model actually saw,
  specials included and padding excluded. The C API exposes the same count as
  `crispembed_last_prompt_tokens()`. Families whose tokenizer count isn't
  observed (LFM2, typed decision, UltraBERT) report 0.
  `CRISPEMBED_SERVER_USAGE_TOKENS=0` restores the old zeros.
- `CRISPEMBED_SERVER_METRICS=1` adds `GET /metrics` (Prometheus text):
  `crispembed_requests_running` (holding a model lock), `_waiting`, `_inflight`,
  admitted/rejected/completed counters, request seconds and reported tokens.
- `CRISPEMBED_SERVER_MAX_INFLIGHT=N` answers POSTs beyond N in flight with
  `429` before any model is touched, instead of queueing them invisibly behind
  the model lock. GET probes are never capped. `CRISPEMBED_SERVER_RETRY_AFTER=S`
  adds a `Retry-After` header to those 429s.
- `CRISPEMBED_SERVER_OPENAI_CHAT=1` adds `POST /v1/chat/completions` and
  `GET /v1/models` for the `--ocr` model. Each request needs the last user
  message to carry exactly one `image_url` as a base64 data URL; its text
  parts become the per-request prompt. Remote/file URLs, streaming, `n>1` and
  tools are rejected rather than ignored. `usage.completion_tokens` is the
  observed decode steps, and `prompt_tokens` is 0 because the OCR ABI doesn't
  expose it. `finish_reason` is `length` only when the decode used the whole
  active cap. Decoded images are limited to `CRISPEMBED_SERVER_MAX_IMAGE_BYTES`
  (default 64 MiB).
- Send `Content-Type: application/json`. Without it, curl's `-d` default
  (`application/x-www-form-urlencoded`) is capped at 8 KiB and returns 413,
  which a page image or a large batch will hit.

```bash
CRISPEMBED_SERVER_OPENAI_CHAT=1 CRISPEMBED_SERVER_METRICS=1 CRISPEMBED_SERVER_MAX_INFLIGHT=4 \
  crispembed-server --ocr qwen2-vl-ocr.gguf   # any --ocr model
curl http://localhost:8080/v1/chat/completions -H 'Content-Type: application/json' -d '{
  "max_tokens": 1024, "messages": [{"role": "user", "content": [
    {"type": "text", "text": "Read the page."},
    {"type": "image_url", "image_url": {"url": "data:image/png;base64,'"$(base64 -w0 page.png)"'"}}]}]}'
```

---

## Install & build

### From source

```bash
# Linux / macOS — CPU
cmake -S . -B build && cmake --build build -j

# GPU backends
cmake -S . -B build -DGGML_CUDA=ON   && cmake --build build -j   # NVIDIA
cmake -S . -B build -DGGML_VULKAN=ON && cmake --build build -j   # cross-platform
cmake -S . -B build -DGGML_BLAS=ON   && cmake --build build -j   # OpenBLAS / MKL

# macOS (recommended: Metal + Accelerate + embedded shaders)
./build-macos.sh            # add --cpu for CPU-only, --shared for the Python lib

# Windows (VS 2022 Build Tools + Ninja)
build-windows.bat           # or build-vulkan.bat / build-cuda.bat
```

**Requirements:** C++17 compiler, CMake ≥ 3.14. Optional: OpenBLAS, Intel MKL,
CUDA Toolkit, or Vulkan SDK. If you see *"ggml does not contain a CMakeLists.txt"*,
run `git submodule update --init --recursive`.

### CPU requirements & redistributable builds

A source build defaults to `-march=native`: it targets **the machine you build
on**, which is the fastest option and the right one for local use.

Binaries you intend to copy to another machine must instead be pinned to a
fixed baseline, or they die with `Illegal instruction` on any CPU that lacks an
extension the build machine had:

```bash
cmake -S . -B build -DGGML_NATIVE=OFF     # portable; CRISPEMBED_NATIVE follows it
python scripts/check-cpu-baseline.py build   # fails the build if it isn't portable
```

The prebuilt release archives and wheels are all built this way. Their floor is:

| Platform | Baseline | Runs on |
|----------|----------|---------|
| x86_64 (Linux / Windows) | SSE4.2 + AVX + AVX2 + FMA + F16C + BMI2 | Intel Haswell (2013) / AMD Excavator (2015) and newer |
| aarch64 (Linux) | `armv8.2-a+fp16+dotprod` | Neoverse N1/V1, Cortex-A76 and newer |
| arm64 (macOS) | Apple clang default for arm64 | Apple Silicon (M1 and newer) |

No release artifact uses AVX-512 or AMX: no current Intel consumer CPU has
them. On a pre-AVX2 CPU, build from source with `-DGGML_NATIVE=OFF
-DGGML_AVX2=OFF -DGGML_AVX=OFF` (much slower, but it runs).

### Linux runtime requirements

The Linux tarballs are self-contained apart from the base C/C++ runtime. They
need only `libc`, `libm`, `libstdc++`, `libgcc_s` and the loader — no BLAS, no
OpenMP, nothing to install. `scripts/check-bundled-deps.py` enforces this at
packaging time:

```bash
python scripts/check-bundled-deps.py pkg    # every DT_NEEDED bundled or base-system
```

That guard exists because it was not always true: up to and including v0.17.0,
`libggml-blas.so.0` carried a hard dependency on `libopenblas.so.0` that the
archive never shipped, so `crispembed-server` died in the dynamic loader with
**exit code 127 and no output** on any machine without OpenBLAS installed
(SubtitleEdit#13205). On an affected release the workaround is
`sudo apt install libopenblas0` / `sudo pacman -S openblas`.

**CUDA on Linux — two archives, pick by what the host already has:**

| archive | size | host must provide |
|---------|------|-------------------|
| `crispembed-linux-x86_64-cuda.tar.gz` | small | NVIDIA driver **and** the CUDA 12.x toolkit runtime (`libcudart`, `libcublas`) |
| `crispembed-linux-x86_64-cuda-bundled.tar.gz` | large | NVIDIA driver only (`libcuda.so.1`) |

The slim archive is the original and keeps its name so existing pins stay
valid — but note its requirement is the **toolkit**, not merely a driver. A
driver alone provides `libcuda.so.1`; `libcudart`/`libcublas` come from the
toolkit, and because `libggml.so` hard-links `libggml-cuda.so`, a driver-only
machine fails at load with exit 127 rather than falling back to CPU (#42). If
you are not sure the toolkit is installed, take the bundled one. Both archives
are checked against their own contract at packaging time.

**glibc floor:** the Linux tarballs are built inside
`quay.io/pypa/manylinux_2_28` and require **glibc ≥ 2.28** — measured at
2.27 / GLIBCXX 3.4.22 — so they run on Ubuntu 18.04+, Debian 10+, RHEL/EL 8+
and any current rolling distro. The packaging gate enforces this
(`check-bundled-deps.py --max-glibc 2.28`), so a future base-image change
cannot silently raise it.

Up to and including v0.17.2 they were built on the runner's Ubuntu 24.04 and
needed **glibc 2.38 / GLIBCXX 3.4.32**, which meant they would not start on
Ubuntu 22.04 or Debian 12 — a second, independent startup failure on top of
the OpenBLAS one (#42). The CUDA archives are still built outside the
container and keep the higher floor.

### Mobile & browser

```bash
./build-ios.sh              # CrispEmbed.xcframework (Metal GPU)
./build-android.sh          # arm64-v8a + armeabi-v7a + x86_64 (Vulkan/NEON)
./build-wasm.sh             # client-side OCR (SIMD / multithreaded / WebGPU tiers)
```

The WASM build runs the full DBNet+TrOCR pipeline, scan-cleanup, and the
auto-detected small OCR engines — math → LaTeX, scene text, and **music
(OMR: SMT / TrOMR / Flova / Transcoda)** — entirely client-side (no server, no API key).
The large VLM/document engines (TeleOCR, MinerU, OXR, Marker, Ovis, MiniCPM-OCR,
Unlimited-OCR, GOT-OCR2, GLM-OCR, InternVL2, LightOnOCR, DeepSeek-OCR2, …) are left out
of the browser build to keep it under 4 MiB; their init returns NULL there. Three
tiers: SIMD CPU, multithreaded (COOP/COEP service worker, works on GitHub Pages),
and experimental **WebGPU** (~2.8× on ViT recognition, ~60× on DBNet detection vs
WASM CPU), in one `.wasm` under 4 MiB. See `examples/wasm-ocr/README.md`.

### As a system library

`cmake --install build --prefix /usr/local` lays out a standard tree with a
versioned `.so`/`.dylib` (SONAME, `RPATH=$ORIGIN`), CMake package config, and a
relocatable pkg-config file:

```cmake
find_package(crispembed REQUIRED)
target_link_libraries(my_app PRIVATE crispembed::crispembed)
```

---

## Text embeddings & retrieval

Ten architectures, auto-detected from GGUF tensor names. Dense, sparse, and
multi-vector heads all run through ggml graphs with GPU dispatch.

### Verified parity (cos vs HuggingFace)

30 embedding models validated at cos ≥ 0.965; a representative slice:

| Model | Type | Dim | F32 | Q8_0 | Q4_K |
|-------|------|-----|-----|------|------|
| all-MiniLM-L6-v2 | BERT | 384 | 0.999999 | 0.9995 | 0.97 |
| multilingual-e5-large | XLM-R | 1024 | 0.999997 | 0.9999 | 0.99 |
| gte-modernbert-base | ModernBERT | 768 | 0.999991 | 0.9999 | — |
| granite-embedding-311m-r2 | ModernBERT | 768 | 1.000000 | 0.9998 | — |
| granite-embedding-97m-r2 | ModernBERT | 384 | 1.000000 | 0.9996 | — |
| nomic-embed-text-v2-moe | NomicBERT MoE | 768 | 1.000000 | 0.9996 | 0.966 |
| EmbeddingGemma-300m | Gemma3 | 768 | 1.000000 | 0.9998 | 0.98 |
| Qwen3-Embedding-0.6B | Qwen3 | 1024 | 0.999895 | 0.9996 | 0.97 |
| Octen-Embedding-8B | Qwen3 | 4096 | — | — | 0.965 |

Q8_0 = all PASS (cos ≥ 0.995). `—` in Q4_K = SwiGLU/GeGLU too sensitive for
aggressive quants (defaults to Q8_0). The full table lives in
[PERFORMANCE.md](PERFORMANCE.md).

CrispEmbed also loads the **official/community `gemma-embedding` GGUFs** directly
(llama.cpp SPM exports, e.g. `ggml-org/embeddinggemma-300m-*-GGUF`). These ship
without the SentenceTransformers Dense head — llama.cpp applies it from an
external file — so their raw output is the backbone mean-pool. Bake the Dense
head in with `models/add-st-dense-to-gguf.py` for HF-compatible embeddings
(cos 0.984 vs HF), or just pull the ready-made `embeddinggemma-300m-qat`.

### MoEdernColBERT and Josev SystemOne (experimental, default-off)

| Model | Registry alias | What | Gates | License |
|---|---|---|---|---|
| SauerkrautLM-MoEdernColBERT 1.5M / 27M / 115M | `moedern-1.5m`, `moedern-27m`, `moedern-115m` | Raw-text query/document multivectors and MaxSim scores (`CrispMoEdern`, `crispembed_moedern_*`) | `CRISPEMBED_MOEDERN_*` (27M/115M also `_FAMILY`) | Apache-2.0 |
| Josev-2B SystemOne | `josev2b-systemone` | Joint-schema text decisions (`--systemone`, `POST /systemone`, `CrispSystemOne`) | `CRISPEMBED_JOSEV_*` + `CRISPEMBED_QWEN35_OCR` | Apache-2.0 |

Gate details: [environment variables](docs/environment-variables.md).

### Sparse, ColBERT & reranking (BGE-M3)

```python
from crispembed import CrispEmbed
model = CrispEmbed("bge-m3.gguf")

vec    = model.encode("Hello world")                 # dense, L2-normalized (1024,)
sparse = model.encode_sparse("Hello world")          # {token_id: weight}   (SPLADE-style)
multi  = model.encode_multivec("Hello world")        # (n_tokens, 128)      (ColBERT)

reranker = CrispEmbed("bge-reranker-v2-m3.gguf")
score = reranker.rerank("query", "document")         # cross-encoder logit
ranked = model.rerank_biencoder("query", ["d1","d2"], top_n=2)   # cosine
```

LFM2.5-ColBERT (128-d per token) and thirteen cross-encoder rerankers are
supported — including the full Ettin family (17M–1B, ModernBERT-based).
Sparse/ColBERT heads are written into the GGUF by the converter and detected
via `has_sparse` / `has_colbert`.

**LFM2.5-Encoder-230M** loads LiquidAI's official GGUFs and exposes raw or
normalized token features plus tied masked-LM predictions. Use
`crispembed -m lfm2-encoder-230m --fill-mask "The capital of France is [MASK]."`
or Python `model.fill_mask(...)` / `model.encode_tokens(..., normalize=False)`.
F16 is the default; CPU inference is validated against the official Python
model. GPU encoder APIs require `CRISPEMBED_LFM2_ENCODER=1` pending GPU parity.
Calibrated downloads are available as `lfm2-encoder-230m-mixed330`,
`lfm2-encoder-230m-mixed210` and `lfm2-encoder-230m-q4k` from
[cstr/LFM2.5-Encoder-230M-GGUF](https://huggingface.co/cstr/LFM2.5-Encoder-230M-GGUF).
For mixed profiles, use `CRISPEMBED_LFM2_F32_DOT=1` for the measured precision mode.
The HTTP server exposes `/tokens`, `/masked-logits` and `/fill-mask`;
`/health` reports `masked_lm` when available.

This is a general-purpose masked encoder; retrieval needs task-specific
fine-tuning. See [usage and parity results](docs/lfm2-encoder.md).

**Byte-level BPE tokenizers transcribe the pre-tokenizer regex the checkpoint
declares** (`src/core/bpe.h`), one per family — Qwen2/Qwen3, LFM2.5, and the
DeepSeek-OCR-2 / Unlimited-OCR Split sequence — validated against HuggingFace's
own `pre_tokenize_str()` in model-free CI. Older builds used a whitespace-split
approximation that collapsed whitespace runs and dropped newlines, so multi-line
documents and non-ASCII punctuation (German typographic quotes, dashes,
currency) tokenized differently from the reference. Set
`CRISPEMBED_BPE_LEGACY_WHITESPACE=1` to restore the old ids for bisection.

---

## OCR & document AI

15+ engines for image → text, most auto-detected from GGUF metadata via the
unified `crispembed_ocr_model_*` C API. Available through CLI (`--ocr`), server
(`POST /ocr/model`), Python (`CrispOcrModel`), Rust, and Dart/Flutter.

### OCR engine matrix

| Model | Architecture | Params | Use case | License |
|-------|-------------|--------|----------|---------|
| **PP-OCRv6** | PPLCNetV4 + light-SVTR + CTC | 5–63 MB | General doc pipeline, best measured CER (see below) | Apache-2.0 |
| **EasyOCR** | VGG/ResNet + BiLSTM + CTC | 16 MB | General doc pipeline, EasyOCR-compatible output | Apache-2.0 |
| **PARSeq** | ViT + Transformer | 24M | Scene text (SOTA, ECCV'22) | Apache-2.0 |
| **DBNet + TrOCR** | ResNet-18+FPNC → DeiT+Transformer | 7+63M | General doc pipeline (~200ms/region) | MIT / Apache-2.0 |
| **Tesseract-LSTM** | VGSL Conv+LSTM+CTC | <2 MB | 12 languages, tiny GGUFs | Apache-2.0 |
| **PP-FormulaNet-L** | SAM-ViT + MBart | 181M | Printed math (best) | Apache-2.0 |
| **MixTeX** | Swin-Tiny + RoBERTa | 86M | CN+EN LaTeX | Apache-2.0 |
| **Texo-Distill** | HGNetv2 + MBart | 20M | Printed math (small) | AGPL-3.0 |
| **PosFormer / BTTR / HMER** | DenseNet + Transformer/GRU | 6–7M | Handwritten math (CROHME) | MIT / CC-BY-NC |
| **SMT** | ConvNext + Transformer | 21M | Printed music (systems) → bekern (96.3% GrandStaff) | MIT |
| **SMT++ full-page** | ConvNext + Transformer | 11M | Whole pianoform *page* → bekern (no segmentation) | MIT |
| **Polyphonic-TrOMR** | ResNetV2+ViT + 4-head decoder | ~22M | Printed music photos → symbolic | Apache-2.0 |
| **Flova/omr_transformer** | DonutSwin + mBART-4L | 143M | Handwritten/whiteboard music → LilyPond | Apache-2.0 |
| **Transcoda-59M** | ConvNeXt-V2 + 8L RoPE cross-attn | 59M | Zero-shot full-page score → Humdrum `**kern` (real-scan SOTA) | CC-BY-4.0 |
| **GOT-OCR2** | SAM ViT-B + Qwen1.5-0.5B | 0.7B | Doc OCR (text+LaTeX+tables); `got-ocr2` / `got-ocr2-f16` (F16-r2, token-exact vs the original pipeline) / `got-ocr2-q8_0-experimental` / `got-ocr2-q8-q4k-mix-experimental` (gold-corpus CER on par with F16, not token-exact) / `got-ocr2-q4_k-experimental` (superseded); needs `CRISPEMBED_ACCEPT_TONGYI_QIANWEN_LICENSE=1` | Tongyi Qianwen Research (non-commercial) |
| **GLM-OCR** | CogViT + GLM-0.5B | 0.9B | Doc OCR (OmniDocBench #1, 8 langs) | MIT |
| **InternVL2 / 2.5** | InternViT + Qwen2/InternLM2.5 | 0.9–2.1B | Edge/WASM & EN+DE VLM OCR | MIT |
| **Qwen2.5-VL / Qwen3-VL** | ViT (+DeepStack) + Qwen LLM | 2.4–3.6B | General/multilingual VLM OCR | Apache-2.0 |
| **[TeleOCR (experimental CPU)](docs/teleocr.md)** | Windowed ViT + QK-normalized Qwen decoder | 1.26B | Default-off (`CRISPEMBED_TELEOCR=1` + `CRISPEMBED_ACCEPT_QWEN_RESEARCH_LICENSE=1`); `teleocr-f16` / `-q8_0` / `-q4_k-m` / `-q4_k-mix` | Qwen Research (non-commercial, vision tower lineage); see [provenance](docs/teleocr-license.md) |
| **[MinerU2.5-Pro-2604 (experimental)](docs/mineru25-pro.md)** | Qwen2-VL graph | 1.2B | Document parsing; `CRISPEMBED_MINERU25_PRO=1`; `mineru25-pro-f16` / `-q8_0` / `-q4_k-mix`; token-exact vs the original on the 8-case protocol | Apache-2.0 |
| **[OXR-1.0 (experimental)](docs/oxr.md)** | SigLIP2-NaViT + Qwen3 | — | Document OCR + native D-FINE layout; `CRISPEMBED_OXR=1` + `CRISPEMBED_ACCEPT_OXR_LICENSE=1`, download with `--accept-license oxr`; `oxr-1.0-f16` / `-q8_0` / `-q4_k-head`, `oxr-1.0-dfine-layout` | OXR License (extra terms) |
| **[OvisOCR2 (experimental)](docs/ovisocr2.md)** | Qwen3.5-OCR format 2 | 853M | CPU, ≤1024 patches, three gates; `ovisocr2-f16` (quantized candidates rejected) | Apache-2.0 |
| **DeepSeek-OCR-2 / Unlimited-OCR** | dual ViT + DeepSeek-V2 MoE | 3–3.3B | Full-page doc OCR + layout grounding | Apache-2.0 / MIT |
| **Unlimited-OCR-2 (experimental)** | SAM + CLIP + DeepSeek-V2 MoE, page-2D RoPE + DASH attention | 3B-class | Default-off (`CRISPEMBED_UNLIMITED_OCR2=1`); registry `unlimited-ocr2` (F16) / `unlimited-ocr2-q8` / `unlimited-ocr2-q8_0-experimental` (Q8_0 + F16 shared experts, ≥ 0.97 on CPU and CUDA); F32 vision products by default, automatic F16 fallback when RAM is short (`CRISPEMBED_UNLIMITED_OCR2_LOW_MEMORY`); [spec](docs/unlimited-ocr2-inference-spec.md) | MIT |
| **MiniCPM-OCR 1.0 (experimental)** | SigLIP + MiniCPM resampler + Qwen3.5 decoder | 1.3B | Default-off (`CRISPEMBED_MINICPM_OCR=1` + `CRISPEMBED_QWEN35_OCR=1`); registry `minicpm-ocr` (F16) / `minicpm-ocr-q8` (Q8_0); engine 23; graph decoder + F32 vision by default (6.2x the old path, token-identical on 20 real pages), low-memory fallback `CRISPEMBED_MINICPM_OCR_LOW_MEMORY`; [spec](docs/minicpm-ocr-inference-spec.md) | Apache-2.0 |
| **jina-ocr-v1** | SAM + CLIP-L + DeepSeek-V2 MoE (Unlimited-OCR engine) | 3.4B (570M active) | Doc OCR → Markdown; text exact vs transformers | CC BY-NC 4.0 |
| **Qari-OCR** | Qwen2-VL-2B + LoRA | 2B | Arabic OCR with diacritics | Apache-2.0 |
| **LFM2.5-VL** | SigLIP2 NaFlex 400M + LFM2 hybrid conv/attn 3B | 3.4B | Doc OCR (VLM); needs `CRISPEMBED_ACCEPT_LFM_LICENSE=1` | LFM-1.0 (revenue-capped) |

#### Measured against the engines we port

`tests/ocr_synth_corpus.py` renders 20 fixtures that carry their own exact
ground truth, and `tests/ocr_external_parity.py` runs the native lanes beside
system Tesseract, Python EasyOCR and Python PaddleOCR on the same images.
Character/word error over that corpus:

| engine | kind | CER | WER |
|---|---|--:|--:|
| `crispembed --ocr-engine ppocrv6` | native | **0.0031** | **0.0178** |
| PaddleOCR 2.10 (Python) | external | 0.0185 | 0.1153 |
| Tesseract 5.5.2 (`--psm 6`) | external | 0.0256 | 0.0890 |
| `crispembed --ocr-engine tesseract` | native | 0.0290 | 0.1623 |
| EasyOCR 1.7.2 (Python) | external | 0.0769 | 0.2363 |
| `crispembed --ocr-engine easyocr` | native | 0.0808 | 0.3190 |

Latency for one CLI invocation of the same page, on an idle machine with
`tesseract` measured before and after as a control (0.12/0.15 s):
`tesseract-cli` 0.135 s, `--ocr-engine tesseract` 0.48 s, `--ocr-engine ppocrv6`
1.39 s, `--ocr-engine easyocr` 1.47 s. `tesseract-cli` is the like-for-like
comparison — one subprocess per image, model load included on both sides.

Reproduce with `python tests/ocr_synth_corpus.py --output <dir>` then
`python tests/ocr_external_parity.py --images <dir> --model-dir <gguf dir>`.
The harness also reports latency, in two columns that are deliberately not
comparable: `proc_ms` covers a whole invocation including model load, while
`engine_ms` excludes it. Run it on an **idle** machine — it prints the
`tesseract-cli` arm as a load control, and if that is far above ~150 ms the
timings are measuring contention rather than the engines.

Formula/music engines validated per-stage against their HF references (typically
cos ≥ 0.999, byte-exact greedy decode). VLM engines ingest the full page and
letterbox internally — the pipeline skips scan-cleanup for them.
`CRISPEMBED_MAX_PIXELS` trades resolution for CPU speed on all variable-resolution
VLMs.

### Optical Music Recognition (OMR)

Three permissively-licensed engines, all auto-detected via `--ocr`:

- **SMT** (MIT, `smt-grandstaff`) — printed polyphonic staff systems → bekern.
  Reproduces the reference exactly (per-stage cos = 1.0, 96.3% vs GrandStaff).
- **SMT++ full-page** (MIT, `smt-fp`) — a whole pianoform *page* → bekern in one
  pass, no staff/system segmentation (per-stage cos ≥ 0.9998, byte-exact greedy
  decode vs the HF reference).
- **Polyphonic-TrOMR** (Apache-2.0) — staff photos → rhythm/pitch/lift streams.
  Robust on real photos; byte-exact decode on the reference examples.
- **Flova/omr_transformer** (Apache-2.0) — the only permissive *handwritten*
  music model; whiteboard "simple notes" → LilyPond, byte-exact incl. the native
  no-`transformers` preprocessing path.
- **Transcoda-59M** (CC-BY-4.0, `transcoda`) — zero-shot *full-page* score →
  Humdrum `**kern` in one pass. ConvNeXt-V2-Tiny encoder + 8-layer RoPE
  cross-attention decoder; OMR-NED SOTA on real historical scans. Clean-room
  engine (per-stage cos = 1.0, byte-exact greedy decode vs the HF reference).

### Layout, detection & preprocessing

- **Layout detection** — RT-DETRv2 (ResNet-50 + deformable decoder), 17 region
  types. `--layout`, `POST /layout/detect`. Encoder cos = 1.0 vs HF; Q8_0 43 MB.
- **Text detection** — Surya EfficientViT segformer (38M, 91 languages,
  GPU-accelerated), plus a model-free connected-component fallback (0 downloads,
  4 ms/page). `--text-detect`.
- **Scan cleanup** — Tier 1 classical (deskew with dual-detector consensus,
  Otsu/Sauvola binarize, border crop, background whitening, cubic-baseline
  dewarp, 1-bit DWA morphology — 21× faster than float, all reimplemented from
  Leptonica). Tier 2 learned NAFNet denoise. `--cleanup-only` / `--cleanup`.
- **Text super-resolution** — PAN (4× whole-page, 0.5 MB), TBSRN (2× per-line,
  2 MB), NAFNet-SR scaffold; parity cos ≥ 0.9996. Eight SR backbones total (HAT,
  DAT, ESRGAN, SwinIR, TBSRN, SAFMN, Restormer, SCUNet).
- **Experimental inpainting** — MI-GAN CPU/F32 removes masked image regions,
  including burned-in subtitles, with same-size PNG output. Includes overlapping
  native-resolution tiles, optional DBNet text masks and a persistent-model
  directory/TSV batch mode. Opt in with `CRISPEMBED_MIGAN=1`; see the
  [inpainting guide](docs/inpainting-cli.md) for model preparation, commands and
  validation limits. Separately gated MI-GAN512, Moebius and PixelHacker
  profiles (shared SDXL VAE) are described in the [engine guide](docs/inpainting-engines.md)
  and published as `migan512-*`, `moebius-*`, `pixelhacker-*`, `sdxl-vae-inpaint-*`
  (non-F32 files also need `CRISPEMBED_INPAINT_QUANT=1`; MI-GAN512 Q4_K is below the
  0.94 bar on one street crop). Video: `--inpaint-stream` with temporal consistency
  (`CRISPEMBED_INPAINT_STREAM=1`). DBNet text masks score thin subtitle lines over
  thresholded pixels (`CRISPEMBED_INPAINT_TEXT_MASK_SCORE_UNDILATED=0` restores the old
  scoring). Representative subtitle/video quality is not yet qualified; LaMa is not
  implemented.
- **PDF DPI profiling** — zero-dependency PDF parser computes effective page DPI
  to auto-select OCR resolution (downsample high-DPI, super-resolve low-DPI).
- **Output formats** — plain text, hOCR, ALTO 3.1 XML, searchable PDF, with
  multi-page accumulation. An **orchestrator** routes by source type
  (screenshot/scan/photo) with accept-gate cascading and VLM fallback.

---

## NER, KIE & language ID

- **NER** — zero-shot **GLiNER** (LFM2.5-350M bidirectional backbone; arbitrary
  entity types at inference, all 16 layers cos = 1.0 vs HF) and fixed-label
  **BERT/XLM-R** (`bert-base-ner` EN, `xlmr-ner-hrl` 10 languages). One `--ner`
  API, backend auto-detected.
- **KIE** — chains OCR + GLiNER to pull key-value fields from receipts/invoices/
  forms, no new model. `--kie`, `POST /kie/extract`, `CrispKIE`.
- **LiLT** — layout-aware document understanding (RoBERTa + layout transformer
  via BiACM), 130M, MIT, FUNSD token classification. 25/25 layers cos = 1.0.
- **LID** — CLD3 (109 langs) / GlotLID (2102 ISO 639-3) text language ID, used to
  auto-select the Tesseract model in the OCR pipeline.

```bash
./build/crispembed -m gliner-lfm --ner "Maria Schmidt arbeitet bei Siemens in München"
# Maria Schmidt → person, Siemens → organization, München → location
```

---

## Vision & face

CLIP and SigLIP text-image cross-modal search (shared vector space), plus a full
face pipeline: YuNet (0.2 MB) / SCRFD (16 MB) detection → ArcFace / SFace /
AuraFace recognition.

```bash
./build/crispembed -m clip-text-base "a photo of a cat"
./build/crispembed -m clip-vit-base-patch16 --image photo.jpg
./build/crispembed -m nomic-embed-vision-v1.5 --image photo.jpg
./build/crispembed -m yunet --detect photo.jpg --json
```

**nomic-embed-vision-v1.5** (Apache-2.0, 92M) embeds images into the space of
`nomic-embed-text-v1.5`: search images with `"search_query: ..."` text
embeddings. Its model card applies a parameter-free LayerNorm (subtract the
mean, divide by the standard deviation) to the *text* vector before L2
normalisation for cross-modal scoring. Image embeddings match transformers at
cosine 1.000000 (F32 and F16, `tools/ci-heavy/nomic_vision.py`).

> **Face recognition is biometric processing.** A face template is
> special-category personal data (GDPR Art. 9), and searching a gallery of them
> (1:N identification) is a high-risk AI system under the EU AI Act. Loading a
> recognition model therefore requires a one-time acknowledgement —
> `--accept-biometric` on the CLI and server, `CRISPEMBED_ACCEPT_BIOMETRIC=1` in
> any process, or `crispembed_accept_biometric_use()` and its Python / Rust /
> Dart equivalents. The check sits in `crispembed_face_init()`, so it holds for
> the bindings too, not just the CLI; detection alone is not gated.
> CrispEmbed provides **no gallery, enrolment, index or 1:N search**
> primitive, and prints cosine similarity without a match/no-match verdict —
> thresholds must be calibrated and documented per deployment.
>
> On the server the acknowledgement is made **once per process**, and there is
> no authentication: every client that can reach the port inherits it, and
> `/face` reads its input by server-side path. It binds `127.0.0.1` by default —
> if you move it off loopback with `--host`, put an authenticating proxy in
> front. Read **[POLICY.md](POLICY.md)** before building on this.
> `examples/face_verify.py` shows 1:1 verification.

**BidirLM-Omni** unifies text, audio, and image into one shared 2048-d space
(bidirectional Qwen3 body + Whisper-shape audio encoder + Qwen2VL vision tower
with DeepStack). Q4_K verified locally across all three modalities.

---

## Language bindings

Python, Rust, Dart, and the CLI expose the same core inference features from the
shared C ABI (dense/batch encode, Matryoshka, prefix, sparse, ColBERT, rerank).

```python
# Python  (needs the shared lib: --shared or -DCRISPEMBED_BUILD_SHARED=ON)
from crispembed import CrispEmbed
model = CrispEmbed("all-MiniLM-L6-v2.gguf")
vecs = model.encode(["Hello world", "Goodbye world"])   # (2, 384), one batched GPU call
model.set_dim(128); model.set_prefix("query: ")
```

```rust
// Rust  —  crispembed = "0.16"          (crates.io; see "Rust crate" below)
let mut model = crispembed::CrispEmbed::new("model.gguf", 0)?;
let vec = model.encode("Hello world");
```

```dart
// Dart / Flutter  (iOS Metal, Android Vulkan/NEON, desktop)
final model = CrispEmbed('model.gguf');
final vec = model.encode('Hello world');   // Float32List(384)
```

```c
/* C ABI */
void *ctx = crispembed_ocr_model_init("ppformulanet-l-q8_0.gguf", 4);
const char *latex = crispembed_ocr_model_recognize(ctx, pixels, w, h, ch, &len);
```

The experimental engines have their own Python wrappers (`CrispMinerU`, `CrispOXR`,
`CrispOXRLayout`, `CrispMarker`, `CrispMoEdern`, `CrispSystemOne`). Their gates apply
to every binding. The C API `crispembed_last_prompt_tokens()` does not have Rust/Dart
wrappers yet. The HTTP server's routes are covered above: embeddings in four dialects,
`/rerank` and `/v1/rerank`, `/ocr/model`, the OCR pipeline, `/systemone`, and the gated
`/metrics` and `/v1/chat/completions`.

Per-language parity scripts (`tests/feature_parity.py`, the Rust/Dart
`feature_parity` examples) verify the wrappers against the CLI. All 45+ registry
models also export as **Ollama-compatible** GGUFs (`--ollama` converter flag).

### Rust crate

```toml
[dependencies]
crispembed = "0.16"          # safe wrapper; crispembed-sys is the raw FFI layer
```

`crispembed-sys` vendors the C/C++ sources and builds them with cmake, so the
crate needs **cmake and a C++17 compiler** but nothing preinstalled — and it
works offline, on docs.rs, and on any target. ggml is linked statically into a
single `libcrispembed`, so there is one library to ship. A cold build takes a
few minutes.

To skip that compile, point the crate at a prebuilt library from the
[releases](https://github.com/CrispStrobe/CrispEmbed/releases) — matching the
crate version — and build.rs links it instead of invoking cmake:

```bash
gh release download v0.16.1 -R CrispStrobe/CrispEmbed -p 'crispembed-macos-arm64.tar.gz'
mkdir -p lib && tar xzf crispembed-macos-arm64.tar.gz -C lib
export CRISPEMBED_SYS_LIB_DIR=$PWD/lib
cargo build       # links the prebuilt; no cmake, no source build
```

No C/C++ sources are needed on this path — not the repository, not the ggml
submodule, not the vendored copy. `build.rs` looks for a prebuilt library
first and only resolves sources if it actually has to compile them. (Between
`a3156a2a` and v0.17.0 it resolved sources unconditionally, so this documented
workflow failed with *"crispembed sources not found"* even with a valid
`CRISPEMBED_SYS_LIB_DIR`; `rust-crates.yml` now regression-tests it.) On native
desktop targets, an unusable directory emits a `cargo:warning` and falls back.
Mobile and other cross targets require an explicit target prebuilt directory
and fail before host discovery or CMake. iOS uses a complete merged static
archive; Android uses a verified shared-library closure. See the
[mobile Rust link contract](docs/rust-mobile-prebuilt.md).

The release tarballs ship `libcrispembed` alongside separate `libggml*`
libraries, so with this path all of them have to travel with your binary — the
from-source default produces just the one. Release assets exist for linux
x86_64/arm64, macOS arm64, Windows x86_64 (plus CUDA/Vulkan variants), Android
and iOS; other native desktop targets (including x86_64 macOS) can use the
source build. Cross builds require a separately prepared target library.

GPU backends are cargo features: `metal`, `cuda`, `vulkan`.

---

## Converting & quantizing models

```bash
# Encoders (BERT / XLM-R) and decoders (Qwen3 / Gemma3)
pip install torch transformers gguf
python models/convert-bert-to-gguf.py --model sentence-transformers/all-MiniLM-L6-v2 --output out.gguf --crisp
python models/convert-decoder-embed-to-gguf.py --model Octen/Octen-Embedding-0.6B --output octen.gguf

# Quantize (Q8_0 recommended; Q4_K for max compression)
./build/crispembed-quantize model.gguf model-q8_0.gguf q8_0

# Import a stock llama.cpp VL model (LLM GGUF + mmproj) byte-for-byte, no re-quant
python models/merge-llamacpp-gguf.py --llm InternVL2_5-1B-Q8_0.gguf \
    --mmproj mmproj-InternVL2_5-1B-f16.gguf --output internvl2_5-1b-crispembed.gguf
```

GGUFs are quantized with an **importance matrix** (imatrix, activation-weighted),
A/B-validated per model class with a task-appropriate metric (mean cosine for
embedders, Kendall-τ for rerankers, span-F1 for NER, etc.). `-m <model>`
auto-downloads each model's best-tested small flavor; `-q8` / `-q4k` / `-iq4xs`
suffixes pick a specific variant.

| Type | Compression | Quality (cos vs F32) |
|------|-------------|----------------------|
| Q8_0 | ~3.8× | > 0.995 (recommended) |
| Q6_K | ~4.5× | > 0.99 |
| Q5_K | ~5× | > 0.98 |
| Q4_K | ~5.5× | > 0.95 (max compression) |

Pre-converted models: **[huggingface.co/cstr](https://huggingface.co/cstr)**.

---

## Performance

Apple M1, Metal, all-MiniLM-L6-v2:

| Engine | Single text | Batch (10) |
|--------|-------------|------------|
| **CrispEmbed** (Python ctypes) | **3.6 ms** / 280 t/s | **12.7 ms** / **787 t/s** |
| fastembed-rs (Rust ONNX) | 3.8 ms / 263 t/s | 18.9 ms / 528 t/s |
| HuggingFace (PyTorch) | 12.2 ms / 82 t/s | 29.8 ms / 335 t/s |

Full multi-model and Ollama Q8_0/Q4_K numbers in [PERFORMANCE.md](PERFORMANCE.md).
Benchmark with `./benchmark.sh [--multi]`.

Recent OCR highlights (details and hosts in PERFORMANCE.md):

- MiniCPM-OCR default path: 506 s for the five-case bench vs 3264 s for the old path and 439 s
  for Transformers; token-identical on 20 real pages.
- Unlimited-OCR-2 F32 vision: about 1.44x faster, IDs and text exact vs the original on the
  trial pages.
- PP-OCRv6 native: CER 0.0031 on the synthetic corpus (table above).

### One-shot CLI startup

Those are *warm* numbers. A one-shot `crispembed -m model.gguf --json "text"`
also pays a fixed init, which used to be ~0.9 s on an M1 and dominated
short-text CLI/scripting use. Measured 2026-08-05, multilingual-e5-small q8_0,
same binary, output byte-identical:

| | one-shot total | Metal device init |
|---|--:|--:|
| before | 895 ms | 683 ms |
| after | **186 ms** (4.8x) | 29 ms |

Almost all of it was ggml-metal's persistent `MTLBinaryArchive` pipeline cache
(`~/Library/Caches/ggml-metal/*.archive`): it is append-only across every
engine and binary on the machine, had grown to 683 MB, and cost ~1 ms/MB to
open — while a one-shot CLI can never write an entry back to it (the archive is
serialised from a static destructor, which `_exit()` skips). CrispEmbed now
skips an archive larger than 64 MB. Env gates:

| Variable | Effect |
|---|---|
| `CRISPEMBED_METAL_PIPELINE_CACHE_MAX_MB=N` | archive size cap in MB (default 64). `0` = uncapped = pre-2026-08-05 behaviour |
| `CRISPEMBED_INIT_BENCH=1` | print the per-component init profile (gguf parse / vocab / tokenizer / backend / weights) to stderr |
| `CRISPEMBED_GGUF_REPARSE=1` | restore the second GGUF metadata parse the loader used to do (~29 ms on a 250k-token vocab) |
| `CRISPEMBED_GPU_PREF_CPU_LEGACY=1` | restore the old behaviour where `--gpu-backend cpu` fell through to the GPU |
| `CRISPEMBED_ONESHOT_CPU=1` | opt in to the CPU backend for a CLI run that did not pass `--gpu-backend` |
| `CRISPEMBED_FORCE_CPU=1` | force the CPU backend for the embedding engine (pre-existing) |

`--gpu-backend cpu` now genuinely skips GPU device init (0.14 s one-shot); it
previously matched no GPU device, warned, and fell back to Metal anyway.
Delete the archive to reclaim the disk — nothing depends on it.

---

## Platform and backend status

| Backend | Status | Caveats |
|---|---|---|
| CPU (x86-64, arm64) | Reference path for every engine | Hosted qualification receipts use the portable build (`GGML_NATIVE=OFF`); `-march=native` can move cosines by ~1e-2 on some VLMs |
| CUDA | Encoders and many OCR/VLM graphs; audited on a T4 | Several engines are CPU-only graphs (UltraBERT, MoEdern, Josev, Ovis/MiniCPM decoders, PP-FormulaNet, …); some quantized VLM recipes qualify on CPU but not CUDA (e.g. Unlimited-OCR-2 Q8_0). See [GPU support matrix](docs/gpu-support-matrix.md) |
| Metal | Encoders, OXR/D-FINE, TeleOCR/MinerU, MI-GAN and others audited on M1 | macOS desktop vectors differ from Linux by up to 2.6e-3 because the Metal backend is selected; `CRISPEMBED_FORCE_CPU=1` matches Linux arm64 within 5e-7 |
| Vulkan | Builds; Android uses it | Few engines measured |
| WASM | Small OCR engines, SIMD / threads / WebGPU tiers | Large VLM engines excluded; packaged embedding vectors differ from native within a documented tolerance (max_abs ≤ 0.0101) |

## Documentation

- [Current state and next steps](docs/current-state-and-next-steps.md) and the latest
  [handoff](docs/handoff-2026-11-03.md); open work in [PLAN.md](PLAN.md), completed work in
  [HISTORY.md](HISTORY.md), numbers in [PERFORMANCE.md](PERFORMANCE.md).
- [Environment variables](docs/environment-variables.md) — every `CRISPEMBED_*` gate.
- [Wiring audit](docs/wiring-audit-20261102.md) — which engine is reachable from which surface.
- [Contributing](docs/contributing.md) — how a model is added and qualified.
- [Precision acceptance](docs/precision-acceptance.md) — the Q8_0/Q4_K bars.

## Where CrispEmbed fits

Part of the Crisp ecosystem, and complementary to llama.cpp (shared ggml backend,
different problem space — retrieval/understanding vs generation):

| Project | Role |
|---|---|
| **CrispEmbed** | This repo — embedding + retrieval + document-AI engine (ggml) |
| **[CrispASR](https://github.com/CrispStrobe/CrispASR)** | Speech recognition (11 ASR backends) + text NMT; shares the ggml core |
| **[crisp-docx](https://github.com/CrispStrobe/crisp-docx)** | `.docx` surgery + document translation; uses CrispEmbed word alignment |
| **[CrispSorter](https://github.com/CrispStrobe/CrispSorter)** | Tauri desktop organiser; LanceDB indexer on CrispEmbed embeddings |

Capabilities llama.cpp does not cover: sparse/ColBERT retrieval, cross-encoder
reranking, the OCR/layout/detection/cleanup/super-resolution document stack, face
detect+recognize, NER/KIE, and a client-side WASM OCR build.

---

## Architecture

Model type is auto-detected from GGUF metadata at load:

- **Encoders** (BERT/XLM-R/MPNet/NomicBERT/ModernBERT/GTE-v1.5/DeBERTa-v2/SPLADE)
  → `src/crispembed.cpp`. Variants detected from tensor names (RoPE vs learned
  positions, rel-attn-bias, pre-LN, fused GeGLU).
- **Decoders** (Qwen3/Gemma3/BidirLM-Omni) → `src/decoder_embed.cpp`.
- **Vision / audio** (BidirLM-Omni) → `src/bidirlm_vision.cpp` /
  `src/bidirlm_audio.cpp`, opened lazily.

The HTTP server exposes four embedding dialects (native, OpenAI, Ollama batch &
legacy) plus face, ViT/CLIP, OCR, NER, LID, KIE, document-OCR, and preprocessing
endpoints. See [PLAN.md](PLAN.md) (roadmap), [HISTORY.md](HISTORY.md) (milestones),
and [LEARNINGS.md](LEARNINGS.md) (deep dives) for detail. Every runtime
`CRISPEMBED_*` switch is listed in [docs/environment-variables.md](docs/environment-variables.md).

---

## Quantized and experimental variants

Quantized files whose output is measurably different from the original are published as
**experimental** (aliases ending in `-experimental`): UltraBERT Q4_K, MoEdernColBERT 27M/115M
Q4_K_MIX, Josev-2B Q8_0/Q4_K_MIX, MiniCPM-OCR and Unlimited-OCR-2 Q4_K_MIX, GOT-OCR2 Q4_K, plus
OXR-1.0 Q8_0-large/Q4_K-head, TeleOCR and MinerU2.5-Pro Q4_K_MIX and MI-GAN512 Q4_K. Per-model
quality tables (token agreement, cosine, retrieval/CER deltas, known divergences) are in
[docs/quantized-models.md](docs/quantized-models.md). Do not mix quantized embedding vectors into an
index built with F32.

## Model licenses

Converting a checkpoint to GGUF **does not relicense it** — each downloaded model
is governed by its **upstream** license. Check the **License** column in
`--list-models` (or the upstream model card) before commercial use.

| License class | Examples | What you can do |
|---|---|---|
| **Permissive** (Apache-2.0 / MIT / CC-BY-4.0) | most BERT/XLM-R/MPNet, BGE, E5, Granite, MXBai, Nomic, Qwen3, Harrier, GTE-v1.5, SMT, TrOMR, Flova, Transcoda (CC-BY-4.0), LiLT | commercial use OK with normal attribution |
| **CC BY-NC 4.0** (non-commercial) | `jina-v5-*`, `jina-reranker-v2`, `jina-ocr-v1`, PosFormer (ours) | research/eval only; commercial needs a vendor license |
| **LFM Open License v1.0** | `lfm2-embed*`, `lfm2-colbert`, `gliner-lfm` | free under $10M annual revenue |
| **Gemma Terms** | `embeddinggemma-300m` | commercial OK, subject to Google's Prohibited Use Policy |
| **Research-only** | `got-ocr2*`, `teleocr-*`, `nanonets-ocr-s`, `qwen2vl-3b` (see the table below) | non-commercial; engine gates require an explicit acknowledgement |
| **Other restricted** | Surya weights (modified OpenRAIL-M; revenue/funding and use restrictions), Texo (AGPL) | see the model card and [current Marker/Surya audit](docs/marker-license.md) |

Restricted entries are flagged with `*` in `--list-models` and require explicit
consent to auto-download (interactive prompt, `--accept-license <spdx>`, or
`CRISPEMBED_ACCEPT_LICENSE`). `--accept-license` acknowledges the caller accepts
upstream terms — it does not grant rights you don't otherwise have. Audit the
whole registry with `python tests/check_registry_licenses.py`.

Apps that ask their own user for consent per model use the per-call C API
instead of the process-wide variable:

| Function | Purpose |
|---|---|
| `crispembed_model_license_info(name, &name, &spdx, &card_url, &display)` | Licence tag, model card URL and description of the entry `name` resolves to; returns `1` when a download needs acceptance, `0` when permissive, `-1` when unknown |
| `crispembed_resolve_model_accepting(name, auto_download, spdx)` | Resolve/download, accepting exactly `spdx` for this call only; `all`, `*` and empty are refused, a model under a different licence is refused, nothing is stored, never prompts |

Rust: `CrispEmbed::model_license_info(name)` / `CrispEmbed::resolve_model_accepting(name, auto_download, spdx)`;
Python: `CrispEmbed.model_license_info(name)` / `CrispEmbed.resolve_model_accepting(...)`;
Dart: `CrispEmbed.modelLicenseInfo(name)` / `CrispEmbed.resolveModelAccepting(...)`.

**Check the base model, not just the fine-tune's tag.** A fine-tune cannot
relicense what it was built on, and the declared tag is sometimes the author's
optimism. The live trap in this family: **Qwen2.5-VL-3B-Instruct is
`qwen-research`** (research-only), while Qwen2.5-VL-7B and Qwen2-VL-2B are
Apache-2.0. So a "Qwen2.5-VL fine-tune" tagged Apache-2.0 is worth checking
before commercial use — we verified `german-ocr-3.1` from its tensor shapes
(hidden 1536, 28 layers ⇒ Qwen2-VL-2B, Apache-2.0) rather than trusting its
card, which credits a nonexistent "Qwen3.5". Note also that HF stores that
licence in the `license_name` field, not `license`, so a checker that reads only
`license` sees nothing at all.

The VLM OCR engines' upstream licences, all verified against the base chain:

| Registry model | Upstream | Base | Licence |
|---|---|---|---|
| `german-ocr-3.1` | keyvan-ai/german-ocr-3.1 | Qwen2-VL-2B-Instruct | Apache-2.0 |
| `nanonets-ocr2-1.5b` | nanonets/Nanonets-OCR2-1.5B-exp | Qwen2-VL-2B-Instruct | Apache-2.0 |
| `nanonets-ocr-s` | nanonets/Nanonets-OCR-s | Qwen2.5-VL-**3B** | Qwen Research (non-commercial) |
| `qwen2vl-3b`, `uni-mumer-qwen2.5-vl-3b`, `teleocr-*` | — | Qwen2.5-VL-3B (vision) | Qwen Research (non-commercial); engine gate `CRISPEMBED_ACCEPT_QWEN_RESEARCH_LICENSE=1` |
| `got-ocr2`, `got-ocr2-f16`, `got-ocr2-q8_0-experimental`, `got-ocr2-q8-q4k-mix-experimental`, `got-ocr2-q4_k-experimental` | stepfun-ai/GOT-OCR2_0 | Qwen1.5-0.5B (decoder) | Tongyi Qianwen Research (non-commercial, no use to improve other LLMs); gate `CRISPEMBED_ACCEPT_TONGYI_QIANWEN_LICENSE=1` |
| `oxr-1.0-*` | OXR-1.0 | — | OXR License (attribution for online services, no competing hosted API); `--accept-license oxr` |
| `h2ovl-mississippi-800m` | h2oai/h2ovl-mississippi-800m | Danube3-500m + InternViT-300M | Apache-2.0 (+ MIT) |
| `h2ovl-mississippi-2b` | h2oai/h2ovl-mississippi-2b | Danube2-1.8b + InternViT-300M | Apache-2.0 (+ MIT) |

---

## Intended purpose & acceptable use

CrispEmbed is a **component**, not a finished AI system: it returns vectors and
text, and every decision made from them happens in your code. Its intended
purpose is retrieval, document understanding, and document preprocessing.

**[POLICY.md](POLICY.md)** states the intended purpose, the prohibited uses
(no scraping facial-image databases, no emotion inference, no biometric
categorisation, no social scoring), and which obligations transfer to you when
you deploy — biometric processing under GDPR Art. 9, EU AI Act Annex III for 1:N
face identification, Art. 50 transparency for generated or manipulated imagery,
and the limits of OCR accuracy. Read it before building on the face pipeline or
the super-resolution engines.

CrispEmbed ships no emotion-recognition, biometric-categorisation, age, gender,
or ethnicity model, and no scraping tooling — absent by design. That constrains
what ships, not what the code can be aimed at: CLIP and SigLIP score an image
against whatever labels you pass, so the caller supplies the classifier. See
[POLICY.md §3](POLICY.md).

**If you operate it, Art. 4 (AI literacy) is yours.** In force since 2 February
2025, it binds deployers as well as providers, and the open-source exemption
does not reach it. In practice it means whoever runs the thing understands that
OCR output is a reconstruction and not a copy, that a cosine similarity is not
a match decision, that face-recognition error rates vary by demographic group,
and that a restored image is a plausible completion rather than recovered
evidence. [POLICY.md §8](POLICY.md).

### Serving it safely

`crispembed-server` has **no authentication**, and its endpoints read images by
*server-side path* (`{"image": "/path/on/the/server"}`). Bound to loopback
(the default) that is a local tool; bound to a routable address it lets any
client read any file the process can — worst on `/face`, which turns one into a
biometric template.

```bash
# Confine every {"image": ...} read to one subtree (resolves .. and symlinks).
crispembed-server --det yunet.gguf --rec arcface.gguf \
    --image-root /srv/scans --host 0.0.0.0 --accept-biometric
```

Set `--image-root` whenever the port is not loopback-only, and put an
authenticating proxy in front of it. Starting `--rec` on a non-loopback bind
warns about exactly this.

### H2OVL and MSAC

`h2ovl-mississippi-2b` sets `use_msac` (Multi-Scale Adaptive Cropping): it was
trained on a **two-scale** tile stack — a coarse grid plus a finer grid that
divides neither of its axes, concatenated `fine[:-1] + coarse[:-1] + fine[-1:]`.
CrispEmbed implements this, so the model reads pages correctly. It matters
because the failure mode is silent: given ordinary single-scale tiles the model
loads, prefills, and returns confident nonsense rather than erroring. The 800m
sibling sets `use_msac: false` and needs none of it. Geometry is pinned by
`tests/test_msac_tiling.cpp` against the upstream algorithm.

### Provenance on image outputs (EU AI Act Art. 50(2))

Image outputs are **PNG by default** and always carry a machine-readable `iTXt`
provenance chunk naming the engine that touched the pixels — Netpbm has no
metadata container, which is why the format changed:

```bash
crispembed --esrgan-model m.gguf --esrgan in.png > out.png
python -c "from PIL import Image; print(Image.open('out.png').info['CrispEmbed'])"
# generated=true / software=CrispEmbed / engine=esrgan-sr
# digitalSourceType=.../algorithmicallyEnhanced
```

The IPTC term is `algorithmicallyEnhanced`, not `trainedAlgorithmicMedia`: the
input is a real capture we enhanced, and claiming wholly-synthetic media would
be false. `CRISPEMBED_IMAGE_FORMAT=ppm` restores the old raw Netpbm output.

**Content Credentials (C2PA)** are added when a signing identity is configured:

```bash
cmake -S . -B build -DCRISPEMBED_C2PA_FETCH=ON     # pull the c2pa-rs native lib
./scripts/make-c2pa-cert.sh                        # per-installation chain
export CRISPEMBED_C2PA_CERT=~/.config/crispembed/c2pa/cert.pem
export CRISPEMBED_C2PA_KEY=~/.config/crispembed/c2pa/key.pem
```

Full reference: [docs/provenance.md](docs/provenance.md).

**No signing key ships with CrispEmbed, on purpose.** A private key in a public
repo would let anyone mint manifests naming CrispEmbed for images it never
touched. A locally generated chain shows as *unverified signer* — it attests
what was done, not who did it. See [POLICY.md §5](POLICY.md).

### Model integrity

Auto-downloaded GGUFs are **SHA-256 pinned** against
[`examples/cli/model_hashes.h`](examples/cli/model_hashes.h), generated from
HuggingFace's LFS object IDs by `tools/fetch_model_hashes.py`. A payload whose
digest does not match is deleted rather than installed, non-HTTPS URLs are
refused, and an unpinned URL is refused unless you set
`CRISPEMBED_ALLOW_UNPINNED_MODEL=1`. A GGUF is a graph this process executes,
so "the download succeeded" is not an integrity statement. After adding a model
to the registry, re-run:

```bash
python tools/fetch_model_hashes.py          # refresh pins
python tools/fetch_model_hashes.py --check  # CI: fail if stale
```

---

## License

CrispEmbed's own code is **MIT** (see [`LICENSE`](LICENSE)), consistent with its
ggml/llama.cpp foundation.

Per-model **weights** are covered by their respective upstream/HuggingFace model
licenses (see [Model licenses](#model-licenses) and `--list-models`) — converting
a checkpoint to GGUF does not change its license. The `crispembed` binary itself
links model runtimes that are mostly permissively licensed (MIT / Apache-2.0 /
CC-BY-4.0 for weights); a few registry models carry non-commercial or
vendor-specific terms and are flagged accordingly.

---

## Credits

- [ggml](https://github.com/ggml-org/ggml) — inference engine
- [CrispASR](https://github.com/CrispStrobe/CrispASR) — shared core (gguf_loader, bpe, crisp_audio)
- [sentence-transformers](https://www.sbert.net/) — ground-truth validation
- The upstream model authors — see each model's card for architecture credit
